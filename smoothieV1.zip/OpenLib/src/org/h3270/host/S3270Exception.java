
package org.h3270.host;


public class S3270Exception extends RuntimeException {

    private static final long serialVersionUID = 2941839322531181864L;

    public S3270Exception(final String message) {
        super(message);
    }

}
