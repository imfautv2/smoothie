 var bar_ctx = document.getElementById("myChart").getContext('2d');
  var numberWithCommas = function(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  };
